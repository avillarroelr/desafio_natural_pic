const Gallery = () => {
  return <div className="gallery grid-columns-5 p-3"></div>;
};
export default Gallery;
