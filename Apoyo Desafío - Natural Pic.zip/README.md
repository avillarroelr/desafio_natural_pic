# React + Vite

## Install

```bash
npm install
```

## Run

```bash
npm run dev
```
